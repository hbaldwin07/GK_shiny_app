library(testthat)
library(svm2)

test_check("svm2")
